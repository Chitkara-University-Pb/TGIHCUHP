
        
        // $(document).ready(function() { // do not reload the page while submitting the page
        // $('form').on('submit', function(event) {
        //     event.preventDefault();
        // })
        // })

        //modal authentication
        let range = document.getElementById("progress").value;
        console.log(range);
        let text = '{ "employees" : [' +
'{ "id":"Abhi123" , "password":"A1234" },' +
'{ "id":"Avi123" , "password":"A1123" },' +
'{ "id":"Mani123" , "password":"M1234" } ]}';
        
        function check(){ 
            
        const obj = JSON.parse(text);
        let obj1 = document.getElementById("userid");
        let obj2 = document.getElementById("userpassword");
        let id=String(obj1.value);
        let pass=String(obj2.value);
        for(let i=0;i<3;i++){      let checkid=String(obj.employees[i].id);
            let checkpass=String(obj.employees[i].password);
            if(id===checkid && pass===checkpass){ 
                obj1.value = "";
                obj2.value = "";
                document.getElementById("modbutton").click();
                return;
            }
                
        }
        obj1.value = "";
        obj2.value = "";
        window.alert("Enter proper userid and password");
    }
        //modal authentication
        let index = 1;
        let left_box = document.getElementById("left_skill");
        let right_box = document.getElementById("right_skill");
        function fetchValue(){ /*while submitting the form data to fetched by this function*/
            let uname = "Manirup";
            let password = "A123";
            let progress = document.getElementById("progress").value;
            let skill_name = document.getElementById("skill").value;
            let retrieve = localStorage.getItem("user");
            if(skill_name.length==0){
                alert("Enter all fields");
                return;
            }
            let newSkill = {"skill":skill_name, "progress":progress};
            newSkill = JSON.stringify(newSkill);
            console.log(retrieve);
            retrieve = JSON.parse(retrieve);
            let skills = [];
            if(retrieve==null)
            {
                skills = [newSkill];
            }
            else
            {
                skills = retrieve["skills"];
                skills.push(newSkill);
            }
            let name = skill_name;
            let user = {"skills":skills};
            localStorage.setItem("user", JSON.stringify(user));
            let storage = localStorage.getItem("user");
             let output =  JSON.parse(storage);
            let ariaValue = progress;
             /*outer div*/
             let outerdiv = document.createElement("div");
             outerdiv.classList.add("progress");
             /*span*/
             let span = document.createElement("span");
             span.classList.add("skill");
             span.innerHTML = name;
             /*ion-icon*/
             let ion_icon = document.createElement("ion-icon");
             ion_icon.classList.add("skill_icon");
             ion_icon.setAttribute("name", "logo");
             /*i tag*/
             let i = document.createElement("i");
             i.classList.add("val");
             i.innerHTML = progress+"%";
             /*add i and ion-icon to span*/
             span.appendChild(ion_icon);
             span.appendChild(i);
             /*add span to outer div*/
             outerdiv.appendChild(span);

             /*inner div*/
             let innerDiv = document.createElement("div");
             innerDiv.classList.add("progress-bar-wrap");
             /*inner div 2*/
             let innerDiv2 = document.createElement("div");
             
             innerDiv2.setAttribute("aria-valuenow", ariaValue);
             
             innerDiv2.setAttribute("aria-valuemin", 0);
             innerDiv2.setAttribute("aria-valuemax", 100);
             innerDiv2.classList.add("progress-bar");
             innerDiv2.setAttribute("role", "progressbar");

            innerDiv2.style.width = ariaValue+"%";
             innerDiv.appendChild(innerDiv2);
            /*add inner div to outer div*/
            outerdiv.appendChild(innerDiv);
            if(index%2!=0)
                left_box.appendChild(outerdiv);
            else
                right_box.appendChild(outerdiv);
            index++;
            document.getElementById("skill").value="";
        }

      
        
        /*fetch the data from the database initially*/
        function updateSkill(){ /*when the loading is complete data should be updated*/
            let retrieve = localStorage.getItem("user");
            retrieve = JSON.parse(retrieve);
            if(retrieve==null)
                console.log();
            else   
            {
                let skills = retrieve["skills"];
                skills.forEach(element => {
                    element = JSON.parse(element);
                    let name = element["skill"];
                    let progress = element["progress"];
                    let ariaValue = parseInt(progress); /*give the skill progress here*/
                    
                    /*outer div*/
                    let outerdiv = document.createElement("div");
                    outerdiv.classList.add("progress");
                    /*span*/
                    let span = document.createElement("span");
                    span.classList.add("skill");
                    span.innerHTML = name;
                    /*ion-icon*/
                    let ion_icon = document.createElement("ion-icon");
                    ion_icon.classList.add("skill_icon");
                    ion_icon.setAttribute("name", "logo");
                    /*i tag*/
                    let i = document.createElement("i");
                    i.classList.add("val");
                    i.innerHTML = progress+"%";
                    /*add i and ion-icon to span*/
                    span.appendChild(ion_icon);
                    span.appendChild(i);
                    /*add span to outer div*/
                    outerdiv.appendChild(span);

                    /*inner div*/
                    let innerDiv = document.createElement("div");
                    innerDiv.classList.add("progress-bar-wrap");
                    /*inner div 2*/
                    let innerDiv2 = document.createElement("div");
                    innerDiv2.classList.add("progress-bar");
                    innerDiv2.setAttribute("role", "progressbar");
                    
                    innerDiv2.setAttribute("aria-valuenow", ariaValue);
                    innerDiv2.setAttribute("aria-valuemin", 0);
                    innerDiv2.setAttribute("aria-valuemax", 100);
                    innerDiv2.style.width = ariaValue+"%";
                    innerDiv.appendChild(innerDiv2);

                    /*add inner div to outer div*/
                    outerdiv.appendChild(innerDiv);

                    if(index%2==0)
                        right_box.appendChild(outerdiv);
                    else
                        left_box.appendChild(outerdiv);
                    index++;
                });
            }
        }
        
  