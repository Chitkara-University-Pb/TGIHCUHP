const funcToSearch = () => {
   let filteredOut = document.getElementById('entry').value.toUpperCase();

   let ourTable = document.getElementById('houses');

   let tr = ourTable.getElementsByTagName('tr');

   for(var index=0;index<tr.length;index++){
       let tableData = tr[index].getElementsByTagName('td')[1];

       if(tableData){
           let textVal = tableData.textContent || tableData.innerHTML;

           if(textVal.toUpperCase().indexOf(filteredOut) > -1){
               tr[index].style.display="";
           }

           else{
               tr[index].style.display="none";
           }
       }
   }
}