//to sign in
function signinButtonClicked() {
    alert("This is working");
    setTimeout(function() {
        window.open("../signin/signin.html", "_self");
    }, 1000);
}