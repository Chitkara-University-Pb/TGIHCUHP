<?php
include_once("mysql-connection.php");
$rid=$_GET["rid"];
$query="delete from meds where rid='$rid'";
mysqli_query($dbcon,$query);
echo "deleted";
?>