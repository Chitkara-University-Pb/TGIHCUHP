<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css_rev/bootstrap.css">
    <script src="js_rev/jquery-1.8.2.min.js"></script>
    <script src="js_rev/bootstrap.bundle.min.js"></script>
<style>
        #btn1{
            text-decoration: none;
            color:black;
            font-size:18px;
        }
    </style>
</head>
<body>
    <center>
        <h2>
        Welcome: <?php echo $_GET["uid"];?> 
        </h2>
        
        <hr>
        <p>
            <h3>
                <?php echo $_GET["msg"]; ?>
            </h3>
            <h4>
                <button class="btn btn-warning" >
                    <a href="project-donor.php" id="btn1">
                    Go Back to Dashboboard
                </a>
                </button>
            </h4>
    
    </center>
</body>
</html>