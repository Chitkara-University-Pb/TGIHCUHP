<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css_rev/bootstrap.css">
    <script src="js_rev/jquery-1.8.2.min.js"></script>
    <script src="js_rev/bootstrap.bundle.min.js"></script>
    <style>
        #titlepic {
            background-image: url(pics1/med-2.png);
            width: 55px;
            height: 55px;
            border-radius:50%;
            background-size: contain;
            background-repeat: no-repeat;
        }
        #logout{
            color:black;
            text-decoration: none;
        }
        #logout:hover{
            text-decoration: underline;
            
        }
        #logoutbtn:hover{
            transform: scale(1.05);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-light" style="background-color:black">
        <div class="container-fluid">
            <a class="navbar-brand" href="#" id="titlepic"></a>
            <span style="font-size: 20px;color:white">Med-Donor</span>
            <form class="d-flex">

                <button class="btn btn-warning" id="logoutbtn"><a href="logout-process.php" id="logout"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;LogOut</a></button>
            </form>
        </div>
    </nav>
</body>

</html>
