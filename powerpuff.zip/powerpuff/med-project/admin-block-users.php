<?php
include_once("mysql-connection.php");
$email=$_GET["email"];
$query="update userss set status=0 where email='$email'";
mysqli_query($dbcon,$query);
$count=mysqli_affected_rows($dbcon);
if($count==1)
{
    echo "blocked";
}
?>
