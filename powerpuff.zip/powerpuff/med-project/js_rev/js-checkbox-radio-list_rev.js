function processCheck() {
    var refc = document.getElementById("chkC");
    var refw = document.getElementById("chkW");
    var refj = document.getElementById("chkJ");
    var res = "";
    if (refc.checked == true) {
        res = res + refc.value + ",";
    }
    if (refw.checked == true) {
        res = res + refw.value + ",";
    }
    if (refj.checked == true) {
        res = res + refj.value + ",";
    }
    res=res.slice(0,-1);
    document.querySelector("#txt").innerHTML = res;
   

}

function checkall() {
    var refall = document.querySelector("#chkall");
    var refc = document.getElementById("chkC");
    var refw = document.getElementById("chkW");
    var refj = document.getElementById("chkJ");
    if (refall.checked == true) {
         refc.checked = true;
         refw.checked = true;
         refj.checked = true;
    } else {
         refc.checked = false;
         refw.checked = false;
         refj.checked = false;
    }
}

function showrad(refbranch,refdiv)
{
    refdiv.innerHTML=refbranch.value;
}

function showstate(ref)
{
    alert(ref.value);
}

function addshow()
{
    var nstate=prompt("enter new state:");
    var opt=document.createElement("option");
    opt.value=nstate;
    opt.text=nstate;
    document.getElementById("states").append(opt);
}