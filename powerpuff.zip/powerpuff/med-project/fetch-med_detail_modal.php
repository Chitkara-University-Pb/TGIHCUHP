<?php
include_once("mysql-connection.php");
$rid=$_GET["ridn"];
$query="select * from meds where rid='$rid'";

$table=mysqli_query($dbcon,$query);
$ary=array();
while($rows=mysqli_fetch_array($table))
{
    $ary[]=$rows;
}
echo json_encode($ary);
?>