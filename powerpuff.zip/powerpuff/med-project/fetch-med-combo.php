<?php
include_once("mysql-connection.php");
$query="select DISTINCT medicine from meds";
$table=mysqli_query($dbcon,$query);
$ary=array();
while($rows=mysqli_fetch_array($table))
{
    $ary[]=$rows;
}
echo json_encode($ary);
?>