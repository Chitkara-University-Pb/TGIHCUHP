<?php
include_once("mysql-connection.php");
$email=$_GET["email"];
$pwd=$_GET["pwd"];
$mobile=$_GET["mobile"];
$category=$_GET["category"];
$query="insert into userss values('$email','$pwd','$mobile','$category',CURRENT_DATE(),1)";
mysqli_query($dbcon,$query);
$msg=mysqli_error($dbcon);
if($msg=="")
{
    echo "record saved..";
}
else{                              
    echo $msg;
}
?>