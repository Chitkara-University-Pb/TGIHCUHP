<?php
include_once("mysql-connection.php");
$rid=$_GET["rid"];
$medicine=$_GET["medicine"];


$qty=$_GET["qty"];


//echo $rid.$medicine;

$query="update meds set medicine='$medicine',qty='$qty' where rid='$rid'";

mysqli_query($dbcon,$query);

$count=mysqli_affected_rows($dbcon);
if($count==1)
{
    echo "updated";
}
?>