<?php
include_once("mysql-connection.php");

$uid=$_POST["uid"];

$fetch="select DISTINCT city from dprofiles where uid='$uid'";
$table=mysqli_query($dbcon,$fetch);

while($rows=mysqli_fetch_array($table))
{
    $cities=$rows['city'];
}

$medname=$_POST["medname"];
$company=$_POST["company"];
$date=$_POST["date"];
$unit=$_POST["unit"];
$qty=$_POST["qty"];
$power=$_POST["power"];
$pic1tmp=$_FILES["pic1"]["tmp_name"];
$pic1name=$_FILES["pic1"]["name"];

$pic2tmp=$_FILES["pic2"]["tmp_name"];
$pic2name=$_FILES["pic2"]["name"];

$pic1full=$uid."-".$pic1name;
$pic2full=$uid."-".$pic2name;

$query="insert into meds(uid,medicine,company,doexp,unit,qty,powerr,pic1,pic2,city) values('$uid','$medname','$company','$date','$unit','$qty','$power','$pic1full','$pic2full','$cities')";
mysqli_query($dbcon,$query);

move_uploaded_file($pic1tmp,"uploads/".$pic1full);
move_uploaded_file($pic2tmp,"uploads/".$pic2full);

$msg=mysqli_error($dbcon);
if($msg=="")
    {
        echo "<script type='text/javascript'> alert('RECORD SUBMITTED SUCCESSFULLY'); 
window.location='project-donor.php'; </script>";
    }
?>