<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DASHBOARD</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="css_rev/bootstrap.css">
    
    <script src="js_rev/jquery-1.8.2.min.js"></script>
    
    <script src="js_rev/bootstrap.bundle.min.js"></script>
    
    <link rel="shortcut icon" href="pics1/med-2.png">
    
    <style>
        
    #idpic{
    height:150px;
    width:150px;
   
    border: 1px black solid;
    border-radius:50%;
    padding:5px;
    margin: auto;
}
        
    </style>
    <script>
        $(document).ready(function(){
            $("#profile").click(function(){
                location.href="needy-profile.php";
            });
            //----------------------------------------
            $("#settings").click(function(){
                var email=$("#email").val();
                var pwd=$("#pwd").val();
                var newpwd=$("#newpwd").val();
                var confpwd=$("#confpwd").val();
                var url="donor-settings.php?email="+ email + "&pwd=" + pwd + "&newpwd=" + newpwd + "&confpwd=" + confpwd;
                $.get(url,function(order){
                    order = order.trim();
                    
                    if(order=="invalid")
                        {
                            $("#errid").html("<i class='fa fa-exclamation-circle' aria-hidden='true'></i>&nbsp;Invalid ID or Password").addClass("not-ok").removeClass("ok");
                        }
                    else
                        if(order=="notmatch")
                        {
                            $("#errconfpwd").html("<i class='fa fa-exclamation-circle' aria-hidden='true'></i>&nbsp; Password not same").addClass("not-ok").removeClass("ok");
                        }
                     else
                        if(order=="updated")
                        {
                            $("#errid").html("<i class='fa fa-check' aria-hidden='true'></i>New Password Updated").removeClass("not-ok").addClass("ok");
                        }
                });
            });
            //--------------------------------------------
        });
    </script>
</head>
<body>
  <?php
    include_once("header.php");
    ?>
   <center>
       <h2>
         &nbsp;
       </h2>
   </center>
   <div class="container">
        <div class="row mt-4">
        <div class="col-md-4">
            <div class="card" style="width: 18rem;">
  <img src="pics2/userlogin.png" id="idpic" class="mt-2">
  <div class="card-body">
    <h5 class="card-title text-center">Create Profile</h5>
    <p class="card-text"></p>
    <center><a href="#" class="btn btn-primary justify-content-center" id="profile">Profile</a></center>
  </div>
</div>
        </div>
   
    <div class="col-md-4">
        <div class="card" style="width: 18rem;" >
            <img src="pics1/setting-logo.webp" id="idpic" class="mt-2">
            <div class="card-body">
                <h5 class="card-title text-center">Settings</h5>
                <p class="card-text"></p>
                <center><div class="btn btn-primary " data-bs-toggle="modal" data-bs-target="#staticBackdrop">change Password</div></center>
            </div>
        </div>
    </div>
    <!------------------------------------------------->

    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h5 class="modal-title" id="staticBackdropLabel">Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="row">
                            <div class="col-md-10 form-group">
                                <label>E-mail</label>
                                <input type="text" name="email" id="email" class="form-control" value="<?php echo $_SESSION['uemail'] ?>" readonly>
                                
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-10 form-group">
                                <label>Password</label>
                                <input type="password" name="pwd" id="pwd" class="form-control">
                                
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-10 form-group">
                                <label>New Password</label>
                                <input type="password" name="newpwd" id="newpwd" class="form-control">
                                
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-10 form-group">
                                <label>Confirm Password</label>
                                <input type="password" name="confpwd" id="confpwd" class="form-control">
                                <div id="errconfpwd">&nbsp;</div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <span id="errid">&nbsp;</span>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" name="settings" id="settings">Change Password</button>
                </div>
            </div>
        </div>
    </div>
    <!------------------------------------------------------->
   
     
        <div class="col-md-4">
            <div class="card" style="width: 18rem;">
  <img src="pics1/medsearch.png" id="idpic" class="mt-2">
  <div class="card-body">
    <h5 class="card-title text-center">Search Medicine</h5>
    <p class="card-text"></p>
    <center><a href="find-medicine.php" class="btn btn-primary" id="search">Search</a></center>
  </div>
</div>
        </div>
     </div>
   </div>
</body>
</html>
























