<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Med-Donor</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css_rev/bootstrap.css">
    <script src="js_rev/jquery-1.8.2.min.js"></script>
    <script src="js_rev/bootstrap.bundle.min.js"></script>
    <link rel="shortcut icon" href="pics1/med-2.png">

    <script>
        $(document).ready(function() {


            $(document).ajaxStart(function() {
                $("#chakkar").css("display", "inline");
            });
            $(document).ajaxStop(function() {
                $("#chakkar").css("display", "none");
            });

            //--------------------------------------
            $("#signup").click(function() {
                var email = $("#email").val();
                var pwd = $("#pwd").val();
                var mobile = $("#mobile").val();
                var category = $("#category").val();
                
                    if(pwd=="")
                    {
                         alert("Please enter password");
                    }
                else 
                    if(mobile=="")
                        {
                             alert("please enter mobile number");
                        }
                else
                    if(category=="")
                    {
                         alert("Please select category");
                    }
                else{
                var url = "project-signup-process.php?email=" + email + "&pwd=" + pwd + "&mobile=" + mobile + "&category=" + category;
                $.get(url, function(resp) {
                    $("#signupresp").html(resp).addClass("ok").removeClass("not-ok");
                });
                }
            });
            //------------------------------------
            $("#email").blur(function() {
                var email = $(this).val();
                var regExp=/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
                if(email=="")
                    {
                        alert("Please enter EmailId");
                    }
                else
                    if(regExp.test(email)==false)
						{
						$("#errUid").html("").removeClass("ok").addClass("not-ok");
							alert("Invalid email id")
					}
                else{
                var url = "project-signupcheck.php?emailid=" + email;
                $.get(url, function(responsex) {
                    $("#erremail").html(responsex).addClass("not-ok").removeClass("ok");
                });
                }
            });
            //-------------------------------------
            /*  $("#emailid").blur(function() {
                  var emailid = $(this).val();
                  var url = "project-logincheck.php?emailid=" + emailid;
                  $.get(url, function(responsex) {
                      $("#erremailid").html(responsex).addClass("not-ok").removeClass("ok");
                  });
              });*/

            //-------------------------------------
            $("#login").click(function() {
                var emailid = $("#emailid").val();
                var idpwd = $("#idpwd").val();
                var url = "project-login.php?emailid=" + emailid + "&idpwd=" + idpwd;
                $.get(url, function(response) {

                    response = response.trim();
                    if (response == "invalid") {
                        //alert("hi");
                        $("#loginresp").html("<i class='fa fa-exclamation-circle' aria-hidden='true'></i>&nbsp;Invalid ID or Password").addClass("not-ok").removeClass("ok");
                    } else
                    if (response == "donor") {
                        location.href = "project-donor.php";
                    } else
                    if (response == "needy") {
                        location.href = "project-needy.php";
                    }
                });
            });
            //--------------------------------------
            $(".fa").mousedown(function() {
                $("#pwd").prop("type", "text");
                $(this).removeClass("fa-eye-slash").addClass("fa-eye");
            });

            $(".fa").mouseup(function() {
                $("#pwd").attr("type", "password");
                $(this).addClass("fa-eye-slash").removeClass("fa-eye");
            });
            //------------------------------------------
             $("#showpwd").mousedown(function() {
                $("#idpwd").prop("type", "text");
                $(this).removeClass("fa-eye-slash").addClass("fa-eye");
            });

            $("#showpwd").mouseup(function() {
                $("#idpwd").attr("type", "password");
                $(this).addClass("fa-eye-slash").removeClass("fa-eye");
            });

        });

    </script>

    <style>
        .ok {
            color: darkgreen;
            float: right;
            font-size: 12px;
        }

        .not-ok {
            color: red;
            float: right;
            font-size: 12px;
        }

        #chakkar {
            display: none;
        }

        #cardpic {
            width: 300px;
            height: 230px;
            background-size: contain;
            
            align-self: center;
            border:1px #f0f0f0 solid;
        }

        #devphead {
            width: inherit;
            padding: 10px;
            background-color: white;
            text-align: center;

        }

        #objectives {
            width: inherit;
            padding: 10px;
            background-color: white;
            text-align: center;
        }

        #reachus {
            width: inherit;
            padding: 10px;
            background-color: white;
            text-align: center;
        }

        #devpout {
            width: inherit;
            padding: 10px;
            background-color: white;
            height: 374px;

        }

       

        #signbtn{
            margin-right:10px;
            width:120px;
            
        }
        #signbtn:active{
            transform: scale(1.05);
        }
#loginbtn{
            margin-right:10px;
            width:120px;
        }
        #loginbtn:active{
            transform: scale(1.05);
        }
        #colortxt{
            color:#f0f0f0;
        }
        #colortxt:hover{
            text-decoration: underline;
        }
        #colortxt:active{
            transform: translate(0px, -3px);
        }
         #titlepic {
            background-image: url(pics1/med-2.png);
            width: 55px;
            height: 55px;
            border-radius:50%;
            background-size: contain;
            background-repeat: no-repeat;
        }
       
        #sirpic{
            float:left;
            width:300px;
            height:350px;
           background-size: contain;
            
            align-self: center;
/*            margin-left:150px;*/
        }
        
        #studpic{
            float:left;
            width:300px;
            height:350px;
           background-size: contain;
            
           align-self: center;
/*            margin-left:150px;*/
        }
        
    </style>

</head>

<body>
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-dark ">
        <div class="container-fluid">
            <a class="navbar-brand" href="#" id="titlepic"></a>
            <span style="font-size: 20px;color:white">Med-Donor</span>
            <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse offset-3" id="navbarNavDropdown">
                <ul class="navbar-nav" id="#fsize">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php" id="colortxt">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#objective" id="colortxt">Objectives</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#aboutus" id="colortxt">About Us</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="#reached" id="colortxt">Reach Us</a>
                    </li>
                    
                </ul>
            
            <!---->
            <div class="btnsu btn btn-warning offset-4" data-bs-toggle="modal" data-bs-target="#signupmodal" id="signbtn"><i class="fa fa-sign-in" aria-hidden="true"></i>&nbsp;Sign-Up</div>
            <!-- Button trigger modal -->
            <!-- ---------------------Modal ---------------------->
            <div class="modal fade" id="signupmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-primary">
                            <h5 class="modal-title" id="staticBackdropLabel">Sign-Up <br></h5>&nbsp;&nbsp;
                            <img id="chakkar" src="pics1/loading9.gif">
                           
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="project-signup-process.php">
                                <div class="row">
                                    <div class="col-md-10 form-group">
                                        <label>E-mail</label>
                                        <input type="text" name="email" id="email" class="form-control" placeholder="e.g.ex93@gmail.com">
                                        <div id="erremail">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-10 form-group">
                                        <label>Password&nbsp;&nbsp;</label>
                                        <input type="password" name="pwd" id="pwd" class="form-control">
                                        <i class="fa fa-eye-slash" aria-hidden="true" style="float:right"></i>
                                    </div>
                                    
                                </div>
                                <div class="row">
                                    <div class="col-md-10 form-group">
                                        <label>Mobile No.</label>
                                        <input type="text" name="mobile" id="mobile" class="form-control">
                                        <div id="errmob">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-10 form-group">
                                        <label>Category</label>
                                        <select type="text" name="category" id="category" class="form-control form-select form-select-lg mb-3">
                                            <option value="none">Select</option>
                                            <option value="donor">Angel</option>
                                            <option value="needy">Needy</option>
                                        </select>
                                    </div>
                                </div>

                            </form>
                        </div>
                        <div class="modal-footer">
                            <span id="signupresp">&nbsp;</span>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" name="signup" id="signup">Sign-Up</button>
                        </div>
                    </div>
                </div>
            </div>
            <!------------------------------------------------------->
            <div class="btnsu btn  btn-warning " data-bs-toggle="modal" data-bs-target="#loginmodal" id="loginbtn"><i class="fa fa-user-circle" aria-hidden="true"></i>&nbsp;Login</div>
            <!---->
            <!-- Modal -->
            <div class="modal fade" id="loginmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-primary">
                            <h5 class="modal-title" id="exampleModalLabel">LOGIN</h5>&nbsp;&nbsp;
                            <img id="chakkar" src="pics1/loading9.gif">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="project-login-process.php">
                                <div class="row">
                                    <div class="col-md-10 form-group">
                                        <label>E-mail</label>
                                        <input type="text" name="emailid" id="emailid" class="form-control" placeholder="e.g.ex93@gmail.com">
                                        <div id="erremailid">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-10 form-group">
                                        <label>Password</label>
                                        <input type="password" name="idpwd" id="idpwd" class="form-control">
                                        <i class="fa fa-eye-slash" aria-hidden="true" style="float:right" id="showpwd"></i>
                                    </div>
                                </div>



                            </form>
                        </div>
                        <div class="modal-footer">
                            <span id="loginresp">&nbsp;</span>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" name="login" id="login">Login</button>
                        </div>
                    </div>
                </div>
            </div>




        </div>
        </div>
    </nav>
    
     <!-- Crousel -->
        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="pics1/medbg2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="pics1/medpic2.jpg" class="d-block w-100" alt="...">
    </div>
    
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"  data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"  data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<!------------------------------------------------->
    <div class="container">
        <div class="row mt-4">
            <div class="col-md-12 text-center bg-dark text-white align-text-bottom" id="objective">
               <h4> OUR OBJECTIVES</h4>
            </div>
        </div>
        <div class="row mt-1 justify-content-center">
    <div class="col-md-3" style="float:left">
        <div class="card" >
  <img src="pics1/med3.webp" class="card-img-top" alt="..." id="cardpic">
  <div class="card-body">
   <h5 class="card-title">Donate Medicine</h5>
    <p class="card-text">The unused medicine can be donated for further utilization by a needy erson.This system helps the user to donate medicines to provide neddy with essential support.Donate food and clothes is undoubtedly appreciated but donate medicines and get to save lives</p>
  </div>
</div>
    </div>
<!--------------------------------------->
<div class="col-md-3" style="float:left">
        <div class="card" >
  <img src="pics1/freemed.jfif" class="card-img-top" alt="..." id="cardpic">
  <div class="card-body">
   <h5 class="card-title">Avail Free Medicine</h5>
    <p class="card-text">Here the medicine donated by generous people can be availed freely without any cost by the needy.<br>&nbsp; <br>&nbsp; <br><br>&nbsp; <br>&nbsp; <br></p>
  </div>
</div>
    </div>
<!---------------------------------------->
<div class="col-md-3" style="float:left">
        <div class="card" >
  <img src="pics1/med5.jpg" class="card-img-top" alt="..." id="cardpic">
  <div class="card-body">
   <h5 class="card-title">Helping Society</h5>
    <p class="card-text">Part of being a person is about helping others.No-one has ever become poor by giving.So strike back against selfishness and greed of moder world and help out a fellow human being today. <br>&nbsp; <br>&nbsp; <br></p>
  </div>
</div>
    </div>
</div>
    <div class="row mt-4">
            <div class="col-md-12 text-center bg-dark text-white align-text-bottom" id="aboutus">
               <h4>ABOUT DEVELOPER</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                
  <img class="card-img-top justify-content-center" src="pics1/rbsir.jpg" alt="Card image cap" id="sirpic">
  <div class="card-body">
   <h5 class="card-title text-center">Developed Under Guidance</h5>
    <h6 class="card-text">
        <table>
            <tr>
                <th>Mentor : </th>
                <td>Rajesh Bansal</td>
            </tr>
            <tr>
                <td colspan="2">(MD and Trainer at Sun-Soft Techonologies)</td>
            </tr>
            <tr>
                <th>Institute : </th>
                <td>Banglore Computer Education</td>
            </tr>
            <tr>
                <th>Email : </th>
                <td>bcebti@gmail.com </td>
            </tr>
        </table>
    </h6>
  </div>
</div>
            </div>
            <div class="col-md-6">
                <div class="card">
                
  <img class="card-img-top justify-content-center" src="pics1/pp2.jpg" alt="Card image cap" id="studpic">
  <div class="card-body">
   <h5 class="card-title text-center">Developer</h5>
    <h6 class="card-text">
        <table>
            <tr>
                <th>Name : </th>
                <td>Simant Jindal</td>
            </tr>
            
            <tr>
                <th>College : </th>
                <td>Chitkara University</td>
            </tr>
            <tr>
                <th>Email : </th>
                <td>simantjindal104@gmail.com </td>
            </tr>
            <tr>
                <th>Contact : </th>
                <td>9023505555</td>
            </tr>
        </table>
    </h6>
  </div>
</div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12 text-center bg-dark text-white align-text-bottom" id="reached">
               <h4>REACH US</h4>
            </div>
            <div class="col-md-12">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3447.8807337916096!2d74.95013941507348!3d30.211951281821662!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391732a4f07278a9%3A0x4a0d6293513f98ce!2sBanglore%20Computer%20Education%20(C%20C%2B%2B%20Android%20J2EE%20PHP%20Python%20AngularJs%20Spring%20Java%20Training%20Institute)!5e0!3m2!1sen!2sin!4v1616247707652!5m2!1sen!2sin" height="450" style="border:0; width:inherit;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
        
    </div>
 <br><br><br>
   <center>
       <font size="2">
           &copy;copyright <br>
           reserved , <br>
           med-donor
       </font>
   </center>
    <br><br><br><br><br>
</body>

</html>
