<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PROFILE</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css_rev/bootstrap.css">
    <script src="js_rev/jquery-1.8.2.min.js"></script>
    <script src="js_rev/bootstrap.bundle.min.js"></script>
    <link rel="shortcut icon" href="pics1/med-2.png">
    <style>
        #pic{
            width:200px;
            height:200px;
            border:2px darkblue solid;
        }
        #pic2{
            width:308px;
            height:200px;
            margin-top:20px;
        }
        body{
            background-image: url(pics1/);
        }
    </style>
    <script>
        $(document).ready(function(){
            $("#fetchall").click(function(){
                var uid=$("#uid").val();
                var url="fetch-needy.php?uid="+uid;
                $.getJSON(url,function(resp){
                    $("#uname").val(resp[0].name);
                    $("#mobile").val(resp[0].mobile);
                    $("#address").val(resp[0].address);
                    $("#city").val(resp[0].city);
                    $("#idproof").val(resp[0].idproof);
                    $("#pnum").val(resp[0].pnum);
                    $("#pic2").prop("src","uploads/"+resp[0].proofpath);
                    
                    $("#hdnname").val(resp[0].name);
                    $("#hdnmobile").val(resp[0].mobile);
                    $("#hdnaddress").val(resp[0].address);
                    $("#hdncity").val(resp[0].city);
                    $("#hdnidproof").val(resp[0].idproof);
                    $("#hdnpnum").val(resp[0].pnum);
                    
                    $("#hdnproof").val(resp[0].proofpath);
                    $("#update").prop("disabled",false);
                });
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <form action="needy-profile-process.php" method="post" enctype="multipart/form-data">
           <div class="row">
               <center>
                   <b>Profile</b>
               </center>
           </div>
           <div class="row">
               <center>
                   <div class="col-md-3 form-group">
                    
                    <img src="pics1/needy.jfif" id="pic">
                    
                </div>
               </center>
           </div>
            <div class="row mt-2">
                <div class="col-md-6 form-group">
                    <label>User ID</label>
                    <input type="text" name="uid" id="uid" class="form-control" value="<?php echo $_SESSION['uemail'] ?>" readonly>
                </div>
                <div class="col-md-2 form-group">
                    <label>&nbsp;</label>
                    <input type="button" name="fetchall" id="fetchall" class="form-control btn btn-warning" value="fetch">
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-6 form-group">
                    <label>Name</label>
                    <input type="text" name="uname" id="uname" class="form-control">
                </div>
                <div class="col-md-6 form-group">
                    <label>Mobile no.</label>
                    <input type="text" name="mobile" id="mobile" class="form-control">
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-6 form-group">
                    <label>Address</label>
                    <input type="text" name="address" id="address" class="form-control">
                </div>
                <div class="col-md-6 form-group">
                    <label>City</label>
                    <input list="cities" class="form-control" name="city" id="city">
                    <datalist id="cities">
                        <option value="Delhi"></option>
                        <option value="Chandigarh"></option>
                        <option value="Bathinda"></option>
                        <option value="Ludhiana"></option>
                        <option value="Jalandhar"></option>
                        <option value="Prayagraj"></option>
                        <option value="Ahemdabad"></option>
                        <option value="Mumbai"></option>
                        <option value="Ranchi"></option>
                        <option value="Patna"></option>
                        <option value="Surat"></option>
                        <option value="Kotkapura"></option>
                        <option value="Banglore"></option>
                        <option value="Pune"></option>
                        <option value="Gurugram"></option>
                        <option value="Noida"></option>
                        <option value="Lucknow"></option>
                        <option value="Jammu"></option>
                        <option value="Baddi"></option>
                        <option value="Dehradun"></option>
                        <option value="Kolkata"></option>
                    </datalist>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-3 form-group">
                    <img src="pics1/idproof.png" id="pic2">
                    <input type="file" name="proof" id="proof" class="form-control">
                </div>
                <div class="col-md-1 form-group">
                    <label>&nbsp;</label>
                    <span>&nbsp;</span>
                </div>
                <div class="col-md-4 form-group">
                    <label>ID Proof</label>
                    <select class="form-control form-select form-select-lg mb-3" id="idproof" name="idproof">
                       <option value="none">Select-id-proof</option>
                        <option value="aadhar">Aadhar Card</option>
                        <option value="liscense">Driving Liscense</option>
                        <option value="passport">Passport</option>
                        <option value="voterid">Voter ID</option>
                        <option value="pan">PAN card</option>
                    </select>
                </div>
                <div class="col-md-4 form-group">
                    <label>Aahar Card Number</label>
                    <input type="text" name="pnum" id="pnum" class="form-control">
                </div>
            </div>
            
            <input type="hidden" name="hdnname" id="hdnname">
            <input type="hidden" name="hdnmobile" id="hdnmobile">
            <input type="hidden" name="hdnaddress" id="hdnaddress">
            <input type="hidden" name="hdncity" id="hdncity">
            <input type="hidden" name="hdnidproof" id="hdnidproof">
            <input type="hidden" name="hdnpnum" id="hdnpnum">
            <input type="hidden" name="hdnpp" id="hdnpp">
            <input type="hidden" name="hdnproof" id="hdnproof">
            
            <div class="row mt-3">
                   
                    <div class="col-md-2 form-group offset-4">
                    <label>&nbsp;</label>
                    <input type="submit" name="btn" value="save" class="form-control btn btn-danger">
                </div>
                <div class="col-md-2 form-group">
                   <label>&nbsp;</label>
                    <input type="submit" name="btn" disabled id="update" value="update" class="form-control btn btn-danger">
                </div>
                
            </div>
        </form>
    </div>
    <br><br><br><br>
</body>
</html>