<?php
include_once("mysql-connection.php");
$medicine=$_GET["medicine"];
$cityname=$_GET["cname"];
$query="select * from meds where medicine='$medicine' and city='$cityname'";

$table=mysqli_query($dbcon,$query);
$ary=array();
while($rows=mysqli_fetch_array($table))
{
    $ary[]=$rows;
}
echo json_encode($ary);
?>