<?php
include_once("mysql-connection.php");
$uid=$_GET["uid"];
$query="select * from nprofiless where uid='$uid'";
$table=mysqli_query($dbcon,$query);
$ary=array();
while($rows=mysqli_fetch_array($table))
{
    $ary[]=$rows;
}
echo json_encode($ary);

?>