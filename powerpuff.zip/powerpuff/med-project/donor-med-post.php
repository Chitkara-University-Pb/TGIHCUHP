<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>POST-MEDICINES</title>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css_rev/bootstrap.css">
    <script src="js_rev/jquery-1.8.2.min.js"></script>
    <script src="js_rev/bootstrap.bundle.min.js"></script>
    <link rel="shortcut icon" href="pics1/med-2.png">
    <style>
        .medpic{
            width:300px;
            height:200px;
            border:3px #f0f0f0 solid;
        }
    </style>
</head>
<body>
    <center>
        <h2>
            Medicenes
        </h2>
    </center>
    <div class="container">
        <form action="donor-med-process.php" method="post" enctype="multipart/form-data">
        <div class="row mt-3">
            <div class="col-md-6 form-group">
                <label>Email-Id</label>
                <input type="text" class="form-control" name="uid" id="uid" value="<?php echo $_SESSION['uemail'] ?>" readonly>
            </div> 
        </div>
<!----------------------------------------------------->
        <div class="row mt-3">
            <div class="col-md-4 form-group">
                <label>Med. Name</label>
                <input type="text" class="form-control" name="medname" id="medname">
            </div>
            <div class="col-md-4 form-group">
                <label>Company</label>
                <input type="text" class="form-control" name="company" id="company">
            </div>
            <div class="col-md-4 form-group">
                <label>Date of Expirey</label>
                <input type="date" class="form-control" name="date" id="date">
            </div>
        </div>
<!------------------------------------------------------->
        <div class="row mt-3">
            <div class="col-md-4 form-group">
                <label>Med. Type</label>
                
                <select class="form-control form-select  mb-3" name="unit" id="unit">
                    <option value="none">Select-med-type</option>
                    <option value="tablets">Tablets</option>
                    <option value="capsules">Capsules</option>
                    <option value="syrup">Syrup</option>
                    <option value="gel">Gel</option>
                </select>
            </div>
            <div class="col-md-4 form-group">
                <label>Quantity</label>
                <input type="text" class="form-control" name="qty" id="qty">
            </div>
            <div class="col-md-4 form-group">
                <label>Potency&nbsp;(in mg)</label>
                
                <input type="text" class="form-control" name="power" id="power">
            </div>
        </div>
<!----------------------------------------------------->
        <div class="row mt-3">
            <div class="col-md-4 form-group">
                <label>&nbsp;</label>
                <img src="pics1/medfront.webp" class="medpic">
                <input type="file" class="form-control" name="pic1" id="pic1">
            </div>
            <div class="col-md-4 form-group">
                <label>&nbsp;</label>
                <img src="pics1/medback.webp" class="medpic">
                <input type="file" class="form-control" name="pic2" id="pic2">
            </div>
            
        </div>
        <!----------------------------------------------------->
        <div class="row mt-5">
            <center>
                <div class="col-md-2 form-group ">
                <label>&nbsp;</label>
                <input type="submit" value="save" name="btn" class="form-control btn btn-danger"> 
            </div>
            </center>
        </div>
    </form>
    </div>
</body>
</html>