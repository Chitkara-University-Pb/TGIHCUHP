<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="css_rev/bootstrap.css">

    <script src="js_rev/jquery-1.8.2.min.js"></script>

    <script src="js_rev/bootstrap.bundle.min.js"></script>
    
    <script>
        $(document).ready(function(){
            $("#user").click(function(){
                location.href="admin-manage-users.php";
            });
        });
    </script>
    <style>
        #idpic {
            height: 150px;
            width: 150px;

            border: 1px black solid;
            border-radius: 50%;
            padding: 5px;
            margin: auto;
        }
    </style>

</head>
<body>
    <div class="container">
        <div class="row">
        <div class="col-md-4">
            
        <div class="card" style="width: 18rem;" id="profile">
            <img src="pics2/userlogin.png" id="idpic">
            <div class="card-body">
                <h5 class="card-title cntr">Manage Users</h5>
                <p class="card-text">&nbsp;</p>
                <a href="#" class="btn btn-primary cntr1" id="user">click</a>
            </div>
        </div>
        </div>
<!-------------------------------------------->
        </div>
    </div>
</body>
</html>