<?php
$dbcon=mysqli_connect("localhost","root","","medicine");

$msg=mysqli_connect_error();
/*
if($msg=="")
{
    echo "connected";
}
*/
?>

