<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>SEARCH MEDICINES</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="css_rev/bootstrap.css">

    <script src="js_rev/jquery-1.8.2.min.js"></script>

    <script src="js_rev/bootstrap.bundle.min.js"></script>

    <script src="js_rev/angular.min.js"></script>
    <link rel="shortcut icon" href="pics1/med-2.png">

    <script>
        var koimodule = angular.module("mymodule", []);
        koimodule.controller("mycontroller", function($http, $scope) {
            $scope.medary = [];
            $scope.fetchmed = function() {
                var url = "fetch-med-combo.php";
                $http.get(url).then(fxok,fxnotok);

                function fxok(resp) {
                    $scope.medary = resp.data;
                }

                function fxnotok(error) {
                    alert(error);
                }
            }
            //-----------------------------------------
            $scope.cityary = [];
            $scope.dofetchcity = function() {
                var med = angular.element("#med").val();
                var url = "fetch-city-combo.php?medicine=" + med;
                $http.get(url).then(fxok, fxnotok);

                function fxok(resp) {

                    $scope.cityary = resp.data;
                }

                function fxnotok(error) {
                    alert(error);
                }
            }
            //-----------------------------------------
            $scope.medinfoary = [];
            $scope.dofetchdetails = function() {
                var med = angular.element("#med").val();
                var cname = angular.element("#cname").val();
                var url = "fetch-meddetails.php?medicine=" + med + "&cname=" + cname;
                $http.get(url).then(fxok, fxnotok);

                function fxok(resp) {
                    //alert(JSON.stringify(resp.data));
                    $scope.medinfoary = resp.data;
                }

                function fxnotok(error) {
                    alert(error);
                }
            }
            //-----------------------------------------
            $scope.meddetailary = [];
            $scope.fetchpartdetail = function(ridv) {

                var url = "fetch-med_detail_modal.php?ridn=" + ridv;
                $http.get(url).then(fxok, fxnotok);

                function fxok(resp) {

                    $scope.meddetailary = resp.data;
                }

                function fxnotok(error) {
                    alert(error);
                }
            }
            //-----------------------------------------
            $scope.contactdetailary=[];
            $scope.fetchcontactdetails = function(uidv) {

                var url = "fetch-contact-detail.php?uidn=" + uidv;
                
                $http.get(url).then(fxok, fxnotok);

                function fxok(resp) {
                    //alert(JSON.stringify(resp.data));
                    $scope.contactdetailary=resp.data;
                }

                function fxnotok(error) {
                    alert(error);
                }
            }
        });

    </script>
    <style>
        .pic1 {
            height: 150px;
            width: 150px;
            border: 1px gray solid;

            

            margin-top: 5px;
            float: left;

        }

        .pic2 {
            height: 150px;
            width: 150px;
            border: 1px gray solid;

            
            margin-top: 5px;
            float: left;
            margin-left: 8px;
        }

        #imagest{
            margin-left:80px;
        }
    </style>
</head>

<body ng-app="mymodule" ng-controller="mycontroller" ng-init="fetchmed();">
    <center>
        <h2>
            Search Medicine
        </h2>
    </center>
    <div class="container mt-3">
        <form>
            <div class="row">
                <div class="col-md-5 form-group">
                    <label>Medicine</label>
                    <input type="list" class="form-control" list="items" id="med" ng-blur="dofetchcity();">
                    <datalist id="items">
                        <option value="{{ele.medicine}}" ng-repeat="ele in medary"></option>
                    </datalist>
                </div>
                <!-- ----------------------------------->
                <div class="col-md-5 form-group">
                    <label>City</label>
                    <select class="form-control form-select  mb-3" id="cname">

                        <option value="{{obj.city}}" ng-repeat="obj in cityary">{{obj.city}}</option>
                    </select>
                </div>
                <!----------------------------------------->
                <div class="col-md-2 form-group">
                    <label>&nbsp;</label>
                    <input type="button" class="form-control btn btn-warning" value="Find Provider" ng-click="dofetchdetails();">
                </div>
            </div>
            <!--------------row-end--------------------->
            <div class="row mt-5">
                <div class="col-md-4" ng-repeat="info in medinfoary">

                    <div class="card" id="profile">
                        <div id="pics" style="float:left;margin:auto;">
                            <img src="uploads/{{info.pic1}}" class="pic1">
                            <img src="uploads/{{info.pic2}}" class="pic2">
                        </div>
                        <div class="card-body">
                            <h5 class="card-title text-center">User {{$index+1}}</h5>
                            <p class="card-text text-center">
                                <label><b>Med. Name : </b></label> <span>{{info.medicine}}</span> <br>
                                <!--                    <label>Company:</label> <span>{{info.company}}</span> <br>-->
                                <label><b>Quantity : </b></label> <span>{{info.qty}}</span> <br>
                                <label><b>Date of Expirey : </b></label> <span>{{info.doexp}}</span> <br>
                            </p>
                            <!-- Button trigger modal -->
                           <center> <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#detailmodal" ng-click="fetchpartdetail(info.rid)">
                                Details
                            </button></center>

                            <!-- Modal -->
                            <div class="modal fade" id="detailmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog" class="modalstyle">
                                    <div class="modal-content">
                                        <div class="modal-header bg-danger">
                                            <h5 class="modal-title" id="staticBackdropLabel">Med and Contact Details</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body" ng-repeat="x in meddetailary">
                                            <!-------------------details in modal---------------->
                                         
                                              <center>
                                               <div class="row">
                                                   <div class="justify-content-center" id="imagest">
                                                      
                                                            <img src="uploads/{{x.pic1}}" class="pic1">
                                                <img src="uploads/{{x.pic2}}" class="pic2">

                                                   </div>
                                               </div>
                                           

                                            
                                               <div class="row">
                                                   <div class="">
                                                        <label><b>Med. Name : </b></label><span>{{x.medicine}}</span><br>
                                                <label><b>Company : </b></label><span>{{x.company}}</span><br>
                                                <label><b>Date of Expirey: </b></label><span>{{x.doexp}}</span><br>
                                                <label><b>Type : </b></label><span>{{x.unit}}</span><br>
                                                <label><b>Quantity : </b></label><span>{{x.qty}}</span><br>
                                                <label><b>Potency : </b></label><span>{{x.powerr}}</span><br>
                                                   </div>
                                               </div>
                                               </center>
                                                <hr bg-color="#f0f0f0">
                                                    <center>
                                                <button type="button" class="btn btn-danger " ng-click="fetchcontactdetails(x.uid);">Contact Details</button>
                                               <hr bg-color="#f0f0f0">
                                                <div ng-repeat="c in contactdetailary">
                                                    
                                                    <label><b>Name : </b></label><span>{{c.name}}</span><br>
                                                    <label><b>contact no. : </b></label><span>{{c.mobile}}</span><br>
                                                    <label><b>Address : </b></label><span>{{c.address}},{{c.city}}</span><br>
                                                </div>
                                                </center>
                                           
                                        
                                        </div>

                                    </div>
                                        <
                                </div>
                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
</body>

</html>
