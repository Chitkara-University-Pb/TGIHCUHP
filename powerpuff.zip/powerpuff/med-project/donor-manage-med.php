<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>MANAGE-MEDICINES</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css_rev/bootstrap.css">
    <script src="js_rev/jquery-1.8.2.min.js"></script>
    <script src="js_rev/bootstrap.bundle.min.js"></script>
    <script src="js_rev/angular.min.js"></script>
    <link rel="shortcut icon" href="pics1/med-2.png">
    <script>
        var koimodule = angular.module("fetchmodule", []);
        koimodule.controller("mycontroller", function($http, $scope) {
            $scope.jsonary = [];
            $scope.dofetch = function() {
                var uid = document.getElementById("uid").value;
                var url = "manage-process.php?uid=" + uid;
                $http.get(url).then(fxok, fxnotok);

                function fxok(resp) {
                    $scope.jsonary = resp.data;
                }

                function fxnotok(error) {
                    alert(error);

                }
            }
            $scope.dodelete = function(rid) {
                if (confirm("Are you Sure?") == false)
                    return;

                var url="manage-med-delete.php?rid=" + rid;
                $http.get(url).then(fxok, fxnotok);

                function fxok(resp) {
                    //alert(resp.data);
                    //$scope.jsonary=resp.data;
                    
                    $scope.dofetch();
                }

                function fxnotok(error) {
                    alert(error);

                }
            }
//---------------------------------------------------------------
            $scope.doupdateshow=function(rid,medicine,qty)
            {
                $scope.nrid=rid;
                $scope.nmedicine=medicine;
                
                $scope.nqty=qty;
                
            }
            //-----------------------------------------------
             $scope.doupdate=function()
            {
                 
                 //var medicine=document.getElementById("medicine");
                 
                 
                // var qty=angular.element("#qty").val();
                 
                var url="manage-med-update.php?rid="+$scope.nrid+"&medicine="+$scope.nmedicine+"&qty="+$scope.nqty;
                $http.get(url).then(fxok,fxnotok);
                function fxok(resp) {
                    //alert(resp.data);
                    
                    $scope.res="updated";
                    $scope.dofetch();
                   
                }

                function fxnotok(error) {
                    alert(error);

                }
            }


        });

    </script>
    
</head>

<body ng-app="fetchmodule" ng-controller="mycontroller">
    <center>
        <h2>Manage Medicines</h2>
    </center>
    <div class="container">
        <form>
            <div class="row mt-3">
                <div class="col-md-6 form-group">
                    <label>Email-Id</label>
                    <input type="text" class="form-control" name="uid" id="uid" value="<?php echo $_SESSION['uemail'] ?>" readonly>
                </div>
                <div class="col-md-2 form-group">
                    <label>&nbsp;</label>
                    <input type="button" class="form-control btn btn-warning" value="fetch" ng-click="dofetch();">
                </div>
            </div>
        </form>
        <!-------------------------------------------------->
        <div class="row mt-3">
            <table class="table table-striped">
                <tr class="bg-info">
                    <th>S.no</th>
                    <th>UID</th>
                    <th>Medicine</th>
                    <th>Company</th>
                    <th>Date of Expirey</th>
                    <th>Type</th>
                    <th>Quantity</th>
                    <th>Potency (in mg)</th>
                    <th>Pic1</th>
                    <th>Pic1</th>
                    <th>Delete</th>
                    <th>Update</th>
                </tr>
                <tr ng-repeat="ele in jsonary">
<!--                   <td>{{ele.rid}}</td>-->
                    <td>{{$index+1}}</td>
                    <td>{{ele.uid}}</td>
                    <td>{{ele.medicine}}</td>
                    <td>{{ele.company}}</td>
                    <td>{{ele.doexp}}</td>
                    <td>{{ele.unit}}</td>
                    <td>{{ele.qty}}</td>
                    <td>{{ele.powerr}}</td>
                    
                    <td>
                        <img src="uploads/{{ele.pic1}}" width="60px" height="60px">
                    </td>
                    <td>
                        <img src="uploads/{{ele.pic2}}" width="60px" height="60px">
                    </td>
                    <td align="center"><i class="fa fa-trash btn " aria-hidden="true" ng-click="dodelete(ele.rid);"></i>
                    </td>

                    <td align="center">
                        <div class="btnsu btn " data-bs-toggle="modal" data-bs-target="#staticBackdrop"  ng-click="doupdateshow(ele.rid,ele.medicine,ele.qty);"><i class="fa fa-pencil-square-o btn" aria-hidden="true"></i></div>
                        <!------------------------------------------------------------------->
                    



                    </td>
                </tr>
            </table>
        </div>
    </div>
        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                        <h5 class="modal-title" id="staticBackdropLabel">UPDATE</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                       <form>
                                            <div class="row">
                                            <div class="col-md-10 form-group">
                                                <label>Med. Name</label>
                                                <input type="text" class="form-control" id="medicine" ng-model="nmedicine">
                                               
                                            </div>
                                        </div>
                                        
                                        
                                        <div class="row">
                                            <div class="col-md-10 form-group">
                                                <label>Quantity</label>
                <input type="text" class="form-control" name="qty" id="qty" ng-model="nqty">
                                            </div>
                                        </div>
                                        
                                        </form>
                                    </div>
                                       
                                       
                                    <div class="modal-footer">
                                       <span>{{res}}</span>
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-primary" ng-click="doupdate(ele.rid);">Update</button>
                                    </div>
                                </div>
                            </div>
                        </div>
</body>

</html>
