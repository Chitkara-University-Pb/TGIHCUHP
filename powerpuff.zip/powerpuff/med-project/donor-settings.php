    <?php
include_once("mysql-connection.php");
$email=$_GET["email"];
$pwd=$_GET["pwd"];
$newpwd=$_GET["newpwd"];
$confpwd=$_GET["confpwd"];

$query="select * from userss where email='$email' and pwd='$pwd'";
$table=mysqli_query($dbcon,$query);
$count=mysqli_num_rows($table);
if($count==1)
{
    if($newpwd==$confpwd)
    {
        $update="update userss set pwd='$newpwd' where email='$email'";
        mysqli_query($dbcon,$update);
        $num=mysqli_affected_rows($dbcon);
        if($num==1)
        {
            echo "updated";
        }
        else{
            echo "Not Updated";
        }
    }
    else{
        echo "notmatch";
    }
    
}
else{
   echo "invalid";
}
?>
