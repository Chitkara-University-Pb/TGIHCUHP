<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="css_rev/bootstrap.css">

    <script src="js_rev/jquery-1.8.2.min.js"></script>

    <script src="js_rev/bootstrap.bundle.min.js"></script>
    
    <script src="js_rev/angular.min.js"></script>
    
    <script>
        var koimodule=angular.module("mymodule",[]);
        koimodule.controller("mycontroller",function($http,$scope){
            $scope.jsonary=[];
            $scope.dofetchall=function()
            {
                var url="admin-fetch-users.php";
                $http.get(url).then(fxok,fxnotok)
                function fxok(resp)
                {
                   //alert(resp.data); 
                    $scope.jsonary=resp.data;
                }
                function fxnotok(error)
                {
                    alert(error);
                }
            }
            //----------------------------------
            $scope.doblock=function(email)
            {
                if(confirm("are you sure?")==false)
                    return;
                
                
                var url="admin-block-users.php?email="+email;
                $http.get(url).then(fxok,fxnotok)
                function fxok(resp)
                {
                   $scope.dofetchall();
                }
                function fxnotok(error)
                {
                    alert(error);
                }
            }
            //----------------------------------
            $scope.doresume=function(email)
            {
                if(confirm("are you sure?")==false)
                    return;
                
                
                var url="admin-resume-users.php?email="+email;
                $http.get(url).then(fxok,fxnotok)
                function fxok(resp)
                {
                   $scope.dofetchall();
                }
                function fxnotok(error)
                {
                    alert(error);
                }
            }
        });
    </script>
    
</head>
<body ng-app="mymodule" ng-controller="mycontroller" ng-init="dofetchall();">
   <center>
       <h2 style="background-color:hotpink;">
           User Manager
       </h2>
   </center>
   <br>
   <table class="table table-striped table-hover">
       <tr>
           <th>email</th>
           <th>Password</th>
           <th>Mobile no.</th>
           <th>Category</th>
           <th>Date of signup</th>
           
           <th>Block</th>
           <th>Resume</th>
       </tr>
       <tr ng-repeat="ele in jsonary">
           <td>{{ele.email}}</td>
           <td>{{ele.pwd}}</td>
           <td>{{ele.mobile}}</td>
           <td>{{ele.category}}</td>
           <td>{{ele.dos}}</td>
           <td>
               <div class="btn text-danger"><i class="fa fa-ban" aria-hidden="true" ng-click="doblock(ele.email);" ng-if="ele.status==1"></i></div>
           </td>
           <td>
               <div class="btn text-success" >
                   <i class="fa fa-refresh" aria-hidden="true" ng-click="doresume(ele.email);" ng-if="ele.status==0"></i>
               </div>
           </td>
       </tr>
   </table>
    
</body>
</html>