<?php
include_once("mysql-connection.php");
$medicine=$_GET["medicine"];
$query="select DISTINCT city from meds where medicine='$medicine'";
$table=mysqli_query($dbcon,$query);
$ary=array();
while($rows=mysqli_fetch_array($table))
{
    $ary[]=$rows;
}
echo json_encode($ary);
?>