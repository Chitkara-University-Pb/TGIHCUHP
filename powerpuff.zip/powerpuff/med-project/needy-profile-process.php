<?php
include_once("mysql-connection.php");

$btn=$_POST["btn"];

if($btn=="save")
{
    $uid=$_POST["uid"];
$name=$_POST["uname"];
$mobile=$_POST["mobile"];
$address=$_POST["address"];
$city=$_POST["city"];
$idproof=$_POST["idproof"];
$pnum=$_POST["pnum"];//proof num



$prooftmp=$_FILES["proof"]["tmp_name"];
$proofname=$_FILES["proof"]["name"];



$prooffull=$uid."-".$proofname;
    $query="insert into nprofiless values('$uid','$name','$mobile','$address','$city','$idproof','$pnum','$prooffull')";
    mysqli_query($dbcon,$query);
    
    move_uploaded_file($prooftmp,"uploads/".$prooffull);
    
    $msg=mysqli_error($dbcon);
    if($msg=="")
    {
        echo "<script type='text/javascript'> alert('SUCCESSFULLY SAVED'); 
window.location='project-needy.php'; </script>";
    }
}
else
    if($btn=="update")
    {
        $uid=$_POST["uid"];
        $name=$_POST["uname"];
        $mobile=$_POST["mobile"];
        $address=$_POST["address"];
        $city=$_POST["city"];
        $idproof=$_POST["idproof"];
        $pnum=$_POST["pnum"];

       

        $prooftmp=$_FILES["proof"]["tmp_name"];
        $proofname=$_FILES["proof"]["name"];
 
        $hdnname=$_POST["hdnname"];
        $hdnmobile=$_POST["hdnmobile"];
        $hdnaddress=$_POST["hdnaddress"];
        $hdncity=$_POST["hdncity"];
        $hdnidproof=$_POST["hdnidproof"];
        $hdnpnum=$_POST["hdnpnum"];
        
        $hdnproof=$_POST["hdnproof"];
        
        if($name=="")
        {
            $uname=$hdnname;
        }
        else{
            $uname=$name;
        }
//----------------------------------------------
        if($mobile=="")
        {
            $umobile=$hdnmobile;
        }
        else{
            $umobile=$mobile;
        }
//----------------------------------------------        
        if($address=="")
        {
            $uaddress=$hdnaddress;
        }
        else{
            $uaddress=$address;
        }
//----------------------------------------------        
        if($city=="")
        {
            $ucity=$hdncity;
        }
        else{
            $ucity=$city;
        }
//----------------------------------------------        
        if($idproof=="")
        {
            $uidproof=$hdnidproof;
        }
        else{
            $uidproof=$idproof;
        }
//----------------------------------------------        
        if($pnum=="")
        {
            $upnum=$hdnpnum;
        }
        else{
            $upnum=$pnum;
        }
//----------------------------------------------        
           
        if($proofname=="")
        {
            $prooffull=$hdnproof;
        }
        else{
            $prooffull=$uid."-".$proofname;
        }
//----------------------------------------------        
        $query="update nprofiless set name='$uname',mobile='$umobile',address='$uaddress',city='$ucity',idproof='$uidproof',pnum='$upnum',proofpath='$prooffull' where uid='$uid'";
    mysqli_query($dbcon,$query);
    
    move_uploaded_file($prooftmp,"uploads/".$prooffull);
    
    $count=mysqli_affected_rows($dbcon);
    if($count==1)
    {
        echo "<script type='text/javascript'> alert('SUCCESSFULLY UPDATED'); 
window.location='project-needy.php'; </script>";
    }
        else
        if($count==0){
            echo "<script type='text/javascript'> alert('NOTHING IS UPDATED'); 
window.location='project-needy.php'; </script>";
        }
        
        
    }
?>