<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php

include_once("mysql-connection.php");
$emailid=$_GET["emailid"];

$query="select * from userss where email='$emailid'";
$table=mysqli_query($dbcon,$query);
$count=mysqli_num_rows($table);
if($count==1)
{
    echo "<i class='fa fa-exclamation-circle' aria-hidden='true'></i>&nbsp;Account already exists..";
}
else{
    echo "&nbsp;";
}

?>
</body>
</html>