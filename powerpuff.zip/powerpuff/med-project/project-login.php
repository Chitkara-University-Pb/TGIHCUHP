<?php
include_once("mysql-connection.php");
session_start();//creation of array
$emailid=$_GET["emailid"];
$_SESSION["uemail"]=$emailid;
 
$idpwd=$_GET["idpwd"];
$query="select * from userss where email='$emailid' and pwd='$idpwd'";
$table=mysqli_query($dbcon,$query);
$count = mysqli_num_rows($table);

if($count == 1)
{
    while($rows=mysqli_fetch_array($table))
    {
        echo $rows['category'];
    }
}
else{
    echo "invalid";
}

?>
